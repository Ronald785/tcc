//About
module.exports.about = (server, req, res) => {
    res.render("centers/about")
}

//Contact
module.exports.contact = (server, req, res) => {
    res.render("centers/contact")
}
